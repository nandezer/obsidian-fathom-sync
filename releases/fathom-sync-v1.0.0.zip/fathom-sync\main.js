var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => FathomSyncPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian5 = require("obsidian");

// src/settings.ts
var import_obsidian = require("obsidian");

// src/utils/logger.ts
var PREFIX = "[Fathom Sync]";
var logger = {
  debug(msg, ...args) {
    console.debug(PREFIX, msg, ...args);
  },
  info(msg, ...args) {
    console.info(PREFIX, msg, ...args);
  },
  warn(msg, ...args) {
    console.warn(PREFIX, msg, ...args);
  },
  error(msg, ...args) {
    console.error(PREFIX, msg, ...args);
  }
};

// src/settings.ts
var DEFAULT_SETTINGS = {
  apiToken: "",
  syncTeams: [],
  recordedByFilter: [],
  syncSummaries: true,
  syncTranscripts: false,
  summaryFolder: "Fathom/Summaries",
  transcriptFolder: "Fathom/Transcripts",
  noteFilenamePattern: "{date} {title}",
  periodicSyncEnabled: false,
  periodicSyncIntervalMinutes: 30,
  lookbackDays: 7,
  lastSyncCursor: ""
};
var FathomSyncSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Fathom Sync" });
    containerEl.createEl("h3", { text: "Authentication" });
    new import_obsidian.Setting(containerEl).setName("API token").setDesc(
      createFragment((frag) => {
        frag.appendText("Your Fathom API key. Generate one at ");
        frag.createEl("a", {
          href: "https://fathom.video/customize#api-access-header",
          text: "fathom.video/customize"
        });
        frag.appendText(".");
      })
    ).addText(
      (text) => text.setPlaceholder("fathom_...").setValue(this.plugin.settings.apiToken).onChange(async (value) => {
        this.plugin.settings.apiToken = value.trim();
        await this.plugin.saveSettings();
      })
    );
    containerEl.createEl("h3", { text: "Filters" });
    new import_obsidian.Setting(containerEl).setName("Sync teams").setDesc(
      "Comma-separated list of team names to sync. Leave empty to sync all meetings you have access to."
    ).addText(
      (text) => text.setPlaceholder("Sales, Engineering").setValue(this.plugin.settings.syncTeams.join(", ")).onChange(async (value) => {
        this.plugin.settings.syncTeams = value.split(",").map((s) => s.trim()).filter(Boolean);
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Recorded by (emails)").setDesc(
      "Comma-separated emails to filter by recorder. Leave empty for all."
    ).addText(
      (text) => text.setPlaceholder("you@example.com, colleague@example.com").setValue(this.plugin.settings.recordedByFilter.join(", ")).onChange(async (value) => {
        this.plugin.settings.recordedByFilter = value.split(",").map((s) => s.trim()).filter(Boolean);
        await this.plugin.saveSettings();
      })
    );
    containerEl.createEl("h3", { text: "Content" });
    new import_obsidian.Setting(containerEl).setName("Sync summaries").setDesc("Download AI-generated meeting summaries.").addToggle(
      (toggle) => toggle.setValue(this.plugin.settings.syncSummaries).onChange(async (value) => {
        this.plugin.settings.syncSummaries = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Sync transcripts").setDesc(
      "Download full speaker-attributed transcripts. Files can be large (50\u2013150 KB each)."
    ).addToggle(
      (toggle) => toggle.setValue(this.plugin.settings.syncTranscripts).onChange(async (value) => {
        this.plugin.settings.syncTranscripts = value;
        await this.plugin.saveSettings();
      })
    );
    containerEl.createEl("h3", { text: "Folders" });
    new import_obsidian.Setting(containerEl).setName("Summaries folder").setDesc("Vault path where summary notes will be saved.").addText(
      (text) => text.setPlaceholder("Fathom/Summaries").setValue(this.plugin.settings.summaryFolder).onChange(async (value) => {
        this.plugin.settings.summaryFolder = value.trim() || "Fathom/Summaries";
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Transcripts folder").setDesc("Vault path where transcript notes will be saved.").addText(
      (text) => text.setPlaceholder("Fathom/Transcripts").setValue(this.plugin.settings.transcriptFolder).onChange(async (value) => {
        this.plugin.settings.transcriptFolder = value.trim() || "Fathom/Transcripts";
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Filename pattern").setDesc(
      "Pattern for note filenames. Available tokens: {date} (YYYY-MM-DD), {title}, {id}."
    ).addText(
      (text) => text.setPlaceholder("{date} {title}").setValue(this.plugin.settings.noteFilenamePattern).onChange(async (value) => {
        this.plugin.settings.noteFilenamePattern = value.trim() || "{date} {title}";
        await this.plugin.saveSettings();
      })
    );
    containerEl.createEl("h3", { text: "Periodic sync" });
    new import_obsidian.Setting(containerEl).setName("Enable periodic sync").setDesc("Automatically sync new meetings on a schedule.").addToggle(
      (toggle) => toggle.setValue(this.plugin.settings.periodicSyncEnabled).onChange(async (value) => {
        this.plugin.settings.periodicSyncEnabled = value;
        await this.plugin.saveSettings();
        this.plugin.reschedulePeriodicSync();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Sync interval (minutes)").setDesc("How often to check for new meetings when periodic sync is on.").addSlider(
      (slider) => slider.setLimits(5, 120, 5).setValue(this.plugin.settings.periodicSyncIntervalMinutes).setDynamicTooltip().onChange(async (value) => {
        this.plugin.settings.periodicSyncIntervalMinutes = value;
        await this.plugin.saveSettings();
        this.plugin.reschedulePeriodicSync();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Lookback window (days)").setDesc(
      "How many days back to look when running a standard sync. Full sync ignores this."
    ).addSlider(
      (slider) => slider.setLimits(1, 90, 1).setValue(this.plugin.settings.lookbackDays).setDynamicTooltip().onChange(async (value) => {
        this.plugin.settings.lookbackDays = value;
        await this.plugin.saveSettings();
      })
    );
    containerEl.createEl("h3", { text: "Actions" });
    new import_obsidian.Setting(containerEl).setName("Full sync").setDesc(
      "Re-sync all reachable meetings, ignoring the lookback window. This may take a while."
    ).addButton(
      (btn) => btn.setButtonText("Run full sync").setCta().onClick(async () => {
        btn.setDisabled(true).setButtonText("Syncing\u2026");
        try {
          await this.plugin.performSync("full");
          new import_obsidian.Notice("Fathom Sync: full sync complete.");
        } catch (err) {
          logger.error("Full sync failed", err);
          new import_obsidian.Notice("Fathom Sync: full sync failed \u2014 check the console.");
        } finally {
          btn.setDisabled(false).setButtonText("Run full sync");
        }
      })
    );
    new import_obsidian.Setting(containerEl).setName("Reset sync cursor").setDesc(
      "Clears the saved pagination cursor so the next standard sync starts from scratch."
    ).addButton(
      (btn) => btn.setButtonText("Reset").onClick(async () => {
        this.plugin.settings.lastSyncCursor = "";
        await this.plugin.saveSettings();
        new import_obsidian.Notice("Fathom Sync: cursor reset.");
      })
    );
  }
};

// src/services/fileSyncService.ts
var import_obsidian2 = require("obsidian");
var FileSyncService = class {
  constructor(app) {
    this.app = app;
    /** recording_id + type → existing TFile */
    this.cache = /* @__PURE__ */ new Map();
  }
  cacheKey(recordingId, type) {
    return `${recordingId}-${type}`;
  }
  /**
   * Scan all markdown files in the vault and build the in-memory cache.
   * Only counts notes that were created BY THIS PLUGIN — identified by the
   * `synced_by: fathom-sync` frontmatter marker. This avoids colliding with
   * other plugins (e.g. Granola Sync) that also use `fathom_id`.
   */
  async buildCache() {
    this.cache.clear();
    const files = this.app.vault.getMarkdownFiles();
    for (const file of files) {
      const cache = this.app.metadataCache.getFileCache(file);
      const fm = cache == null ? void 0 : cache.frontmatter;
      if (!(fm == null ? void 0 : fm.fathom_id) || !(fm == null ? void 0 : fm.type)) continue;
      if (fm.synced_by !== "fathom-sync") continue;
      if (fm.type !== "summary" && fm.type !== "transcript") continue;
      const key = this.cacheKey(Number(fm.fathom_id), fm.type);
      this.cache.set(key, file);
    }
    logger.info(`Cache built: ${this.cache.size} Fathom Sync notes found.`);
  }
  has(recordingId, type) {
    return this.cache.has(this.cacheKey(recordingId, type));
  }
  /**
   * Write a note to the vault.
   * If the note already exists in the cache it is skipped (immutable).
   * Returns true if the note was written, false if skipped.
   */
  async saveNote(recordingId, type, note) {
    var _a;
    const key = this.cacheKey(recordingId, type);
    if (this.cache.has(key)) {
      logger.debug(`Skipping existing note: ${key}`);
      return false;
    }
    const folderPath = (0, import_obsidian2.normalizePath)(note.folder);
    const filePath = (0, import_obsidian2.normalizePath)(`${note.folder}/${note.filename}.md`);
    await this.ensureFolder(folderPath);
    try {
      const file = await this.app.vault.create(filePath, note.content);
      this.cache.set(key, file);
      logger.info(`Created: ${filePath}`);
      return true;
    } catch (err) {
      if ((_a = err == null ? void 0 : err.message) == null ? void 0 : _a.includes("already exists")) {
        logger.warn(`File already exists, updating cache entry: ${filePath}`);
        const existing = this.app.vault.getAbstractFileByPath(filePath);
        if (existing instanceof import_obsidian2.TFile) {
          this.cache.set(key, existing);
        }
        return false;
      }
      throw err;
    }
  }
  async ensureFolder(folderPath) {
    const exists = this.app.vault.getAbstractFileByPath(folderPath);
    if (!exists) {
      await this.app.vault.createFolder(folderPath);
    }
  }
};

// src/services/syncService.ts
var import_obsidian4 = require("obsidian");

// src/services/fathomApi.ts
var import_obsidian3 = require("obsidian");
var BASE_URL = "https://api.fathom.ai/external/v1";
var FathomApiError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
    this.name = "FathomApiError";
  }
};
var FathomApiClient = class {
  constructor(apiToken) {
    /**
     * Token-bucket-ish throttle: Fathom rate-limits at 60 req/min, so we
     * keep ~1.1s between calls. With this we can run unlimited meetings
     * without ever hitting 429 in the steady state.
     */
    this.nextSlot = 0;
    this.minInterval = 1100;
    this.headers = {
      "X-Api-Key": apiToken,
      "Content-Type": "application/json"
    };
  }
  // ms
  async throttle() {
    const now = Date.now();
    if (now < this.nextSlot) {
      await new Promise((r) => setTimeout(r, this.nextSlot - now));
    }
    this.nextSlot = Math.max(now, this.nextSlot) + this.minInterval;
  }
  /**
   * Wrapper around Obsidian's requestUrl() that bypasses Electron CORS.
   * We use throw: false so non-2xx responses don't blow up before we can
   * read the body for diagnostics. Retries once on 429 after a backoff.
   */
  async call(path, query, retriesOn429 = 2) {
    var _a, _b;
    await this.throttle();
    const url = query ? `${BASE_URL}${path}?${query.toString()}` : `${BASE_URL}${path}`;
    const params = {
      url,
      method: "GET",
      headers: this.headers,
      throw: false
    };
    const response = await (0, import_obsidian3.requestUrl)(params);
    if (response.status === 429 && retriesOn429 > 0) {
      const retryAfterHeader = (_a = response.headers) == null ? void 0 : _a["retry-after"];
      const retryAfter = retryAfterHeader ? Number(retryAfterHeader) : 30;
      const waitMs = Math.max(1e3, retryAfter * 1e3);
      console.warn(`[Fathom Sync] Rate-limited; backing off ${waitMs}ms`);
      await new Promise((r) => setTimeout(r, waitMs));
      return this.call(path, query, retriesOn429 - 1);
    }
    if (response.status < 200 || response.status >= 300) {
      const body = ((_b = response.text) != null ? _b : "").slice(0, 500);
      throw new FathomApiError(
        response.status,
        `Fathom API ${response.status}: ${body || "no response body"}`
      );
    }
    return response.json;
  }
  /**
   * Fetch a single page of meetings.
   * Use `listAllMeetings` for full pagination.
   */
  async listMeetings(opts) {
    var _a, _b;
    const q = new URLSearchParams();
    if ((_a = opts.teams) == null ? void 0 : _a.length) {
      for (const t of opts.teams) q.append("teams[]", t);
    }
    if ((_b = opts.recordedBy) == null ? void 0 : _b.length) {
      for (const e of opts.recordedBy) q.append("recorded_by[]", e);
    }
    if (opts.createdAfter) q.set("created_after", opts.createdAfter);
    if (opts.createdBefore) q.set("created_before", opts.createdBefore);
    if (opts.includeSummary) q.set("include_summary", "true");
    if (opts.cursor) q.set("cursor", opts.cursor);
    return this.call("/meetings", q);
  }
  /**
   * Iterate all pages and return every meeting matching the filters.
   * Stops early when `onPage` returns false.
   */
  async listAllMeetings(opts, onPage) {
    var _a;
    const all = [];
    let cursor;
    do {
      const page = await this.listMeetings({ ...opts, cursor });
      const meetings = (_a = page.items) != null ? _a : [];
      if (!Array.isArray(meetings)) {
        throw new FathomApiError(
          0,
          `Unexpected response shape \u2014 expected items to be an array. Got: ${JSON.stringify(page).slice(0, 300)}`
        );
      }
      all.push(...meetings);
      const shouldContinue = onPage == null ? void 0 : onPage(meetings, page.next_cursor);
      if (shouldContinue === false) break;
      cursor = page.next_cursor;
    } while (cursor);
    return all;
  }
  async getSummary(recordingId) {
    var _a, _b, _c;
    const raw = await this.call(`/recordings/${recordingId}/summary`);
    if (raw && typeof raw === "object") {
      const obj = raw;
      const nested = (_a = obj.summary) != null ? _a : obj.default_summary;
      if (nested && typeof nested.markdown_formatted === "string") {
        return nested;
      }
      if (typeof obj.markdown_formatted === "string") {
        return obj;
      }
      if (typeof obj.markdown === "string") {
        return { template_name: String((_b = obj.template_name) != null ? _b : "default"), markdown_formatted: obj.markdown };
      }
      if (typeof obj.content === "string") {
        return { template_name: String((_c = obj.template_name) != null ? _c : "default"), markdown_formatted: obj.content };
      }
    }
    console.warn(`[Fathom Sync] Empty/unknown summary shape for recording ${recordingId}`);
    return { template_name: "default", markdown_formatted: "" };
  }
  async getTranscript(recordingId) {
    const raw = await this.call(`/recordings/${recordingId}/transcript`);
    if (Array.isArray(raw)) return raw;
    if (raw && typeof raw === "object") {
      const obj = raw;
      if (Array.isArray(obj.segments)) return obj.segments;
      if (Array.isArray(obj.transcript)) return obj.transcript;
      if (Array.isArray(obj.items)) return obj.items;
      console.warn(
        `[Fathom Sync] Unknown transcript shape for recording ${recordingId}. Keys: ${Object.keys(obj).join(", ")}. Sample: ${JSON.stringify(raw).slice(0, 400)}`
      );
    }
    return [];
  }
  async listTeams() {
    return this.call("/teams");
  }
};

// src/utils/dateUtils.ts
function isoToDate(iso) {
  return iso.slice(0, 10);
}
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function daysAgoIso(days) {
  const d = /* @__PURE__ */ new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString();
}
function toSafeFilename(value) {
  return value.replace(/[\\/:*?"<>|]/g, "-").trim();
}

// src/services/documentProcessor.ts
var DocumentProcessor = class {
  constructor(settings) {
    this.settings = settings;
  }
  buildFilename(meeting) {
    const date = isoToDate(meeting.created_at);
    const title = toSafeFilename(meeting.title || "Untitled");
    const id = String(meeting.recording_id);
    let pattern = this.settings.noteFilenamePattern || "{date} {title}";
    if (!pattern.includes("{date}") && !pattern.includes("{title}") && !pattern.includes("{id}")) {
      pattern = "{date} {title}";
    }
    const result = pattern.replace(/\{date\}/g, date).replace(/\{title\}/g, title).replace(/\{id\}/g, id).trim();
    return result.includes(id) ? result : `${result} (${id})`;
  }
  buildSummaryNote(meeting, summary, transcriptPath) {
    var _a, _b, _c, _d, _e;
    const filename = this.buildFilename(meeting);
    const folder = this.settings.summaryFolder;
    const recorderName = (_b = (_a = meeting.recorded_by) == null ? void 0 : _a.name) != null ? _b : "Unknown";
    const recorderEmail = (_d = (_c = meeting.recorded_by) == null ? void 0 : _c.email) != null ? _d : "";
    const attendees = ((_e = meeting.calendar_invitees) != null ? _e : []).map((a) => a.name);
    const frontmatter = [
      "---",
      `fathom_id: ${meeting.recording_id}`,
      `fathom_url: "${meeting.url}"`,
      `title: "${escapeFrontmatterString(meeting.title)}"`,
      `recorded_by: "${escapeFrontmatterString(recorderName)}"`,
      `recorded_by_email: "${escapeFrontmatterString(recorderEmail)}"`,
      `attendees:`,
      ...attendees.map((a) => `  - "${escapeFrontmatterString(a)}"`),
      `created_at: "${meeting.created_at}"`,
      `synced_at: "${nowIso()}"`,
      `synced_by: fathom-sync`,
      `type: summary`,
      transcriptPath ? `transcript: "[[${transcriptPath}]]"` : null,
      "---"
    ].filter((line) => line !== null).join("\n");
    const body = [
      `# ${meeting.title}`,
      "",
      `[View recording](${meeting.url})  `,
      `**Recorded by:** ${recorderName}  `,
      `**Attendees:** ${attendees.join(", ") || "\u2014"}`,
      "",
      "## Summary",
      "",
      summary.markdown_formatted
    ].join("\n");
    return { filename, folder, content: `${frontmatter}

${body}
` };
  }
  buildTranscriptNote(meeting, segments, summaryPath) {
    const filename = this.buildFilename(meeting);
    const folder = this.settings.transcriptFolder;
    const frontmatter = [
      "---",
      `fathom_id: ${meeting.recording_id}`,
      `fathom_url: "${meeting.url}"`,
      `title: "${escapeFrontmatterString(meeting.title)}"`,
      `type: transcript`,
      `synced_by: fathom-sync`,
      `note: "[[${summaryPath}]]"`,
      `synced_at: "${nowIso()}"`,
      "---"
    ].join("\n");
    const safeSegments = Array.isArray(segments) ? segments : [];
    const lines = safeSegments.map((seg) => {
      const secs = hhmmssToSeconds(seg.timestamp);
      const link = `${meeting.url}?timestamp=${secs}`;
      const speakerName = speakerToString(seg.speaker);
      return `[${seg.timestamp}](${link}) **${speakerName}:** ${seg.text}`;
    });
    const body = [
      `# ${meeting.title} \u2014 Transcript`,
      "",
      `[View recording](${meeting.url})`,
      "",
      ...lines
    ].join("\n");
    return { filename, folder, content: `${frontmatter}

${body}
` };
  }
};
function escapeFrontmatterString(value) {
  return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}
function speakerToString(speaker) {
  if (!speaker) return "Unknown";
  if (typeof speaker === "string") return speaker;
  if (typeof speaker === "object") {
    const obj = speaker;
    return typeof obj.display_name === "string" && obj.display_name || typeof obj.name === "string" && obj.name || typeof obj.email === "string" && obj.email || "Unknown";
  }
  return String(speaker);
}
function hhmmssToSeconds(timestamp) {
  const parts = timestamp.split(":").map(Number);
  if (parts.length === 3) {
    return parts[0] * 3600 + parts[1] * 60 + parts[2];
  }
  if (parts.length === 2) {
    return parts[0] * 60 + parts[1];
  }
  return 0;
}

// src/services/syncService.ts
var SyncService = class {
  constructor(settings, fileSync, onSettingsChange) {
    this.settings = settings;
    this.fileSync = fileSync;
    this.onSettingsChange = onSettingsChange;
    this.api = new FathomApiClient(settings.apiToken);
    this.processor = new DocumentProcessor(settings);
  }
  async performSync(mode) {
    if (!this.settings.apiToken) {
      new import_obsidian4.Notice("Fathom Sync: API token not configured. Open settings to add it.");
      throw new Error("Missing API token");
    }
    logger.info(`Starting ${mode} sync\u2026`);
    await this.fileSync.buildCache();
    const result = {
      summariesCreated: 0,
      transcriptsCreated: 0,
      skipped: 0,
      errors: 0
    };
    const createdAfter = mode === "standard" ? daysAgoIso(this.settings.lookbackDays) : void 0;
    let lastSeenCursor;
    const meetings = await this.api.listAllMeetings(
      {
        teams: this.settings.syncTeams.length ? this.settings.syncTeams : void 0,
        recordedBy: this.settings.recordedByFilter.length ? this.settings.recordedByFilter : void 0,
        createdAfter,
        includeSummary: false
        // we fetch summary individually to avoid payload bloat
      },
      (_page, cursor) => {
        lastSeenCursor = cursor;
      }
    );
    logger.info(`Fetched ${meetings.length} meetings from Fathom.`);
    for (const meeting of meetings) {
      try {
        await this.processMeeting(meeting, result);
      } catch (err) {
        result.errors++;
        logger.error(`Error processing meeting ${meeting.recording_id}:`, err);
        if (err instanceof FathomApiError && err.status === 401) {
          new import_obsidian4.Notice("Fathom Sync: invalid API token. Check your settings.");
          throw err;
        }
      }
    }
    if (mode === "standard" && lastSeenCursor !== void 0) {
      await this.onSettingsChange({ lastSyncCursor: lastSeenCursor });
    }
    logger.info(
      `Sync complete. Summaries: ${result.summariesCreated}, Transcripts: ${result.transcriptsCreated}, Skipped: ${result.skipped}, Errors: ${result.errors}`
    );
    return result;
  }
  async processMeeting(meeting, result) {
    const summaryAlreadyExists = this.fileSync.has(meeting.recording_id, "summary");
    const transcriptAlreadyExists = this.fileSync.has(meeting.recording_id, "transcript");
    const needSummary = this.settings.syncSummaries && !summaryAlreadyExists;
    const needTranscript = this.settings.syncTranscripts && !transcriptAlreadyExists;
    if (!needSummary && !needTranscript) {
      result.skipped++;
      return;
    }
    const filename = this.processor.buildFilename(meeting);
    if (needSummary) {
      const summary = await this.api.getSummary(meeting.recording_id);
      const transcriptPath = this.settings.syncTranscripts ? `${this.settings.transcriptFolder}/${filename}` : void 0;
      const note = this.processor.buildSummaryNote(meeting, summary, transcriptPath);
      const wrote = await this.fileSync.saveNote(meeting.recording_id, "summary", note);
      if (wrote) result.summariesCreated++;
      else result.skipped++;
    }
    if (needTranscript) {
      const segments = await this.api.getTranscript(meeting.recording_id);
      const summaryPath = `${this.settings.summaryFolder}/${filename}`;
      const note = this.processor.buildTranscriptNote(meeting, segments, summaryPath);
      const wrote = await this.fileSync.saveNote(meeting.recording_id, "transcript", note);
      if (wrote) result.transcriptsCreated++;
      else result.skipped++;
    }
  }
};

// src/main.ts
var FathomSyncPlugin = class extends import_obsidian5.Plugin {
  constructor() {
    super(...arguments);
    this.periodicSyncIntervalId = null;
  }
  async onload() {
    await this.loadSettings();
    this.initServices();
    this.statusBarItem = this.addStatusBarItem();
    this.setStatusBar("Fathom Sync ready");
    this.addRibbonIcon("refresh-cw", "Fathom Sync: sync now", async () => {
      await this.triggerSync("standard");
    });
    this.addCommand({
      id: "fathom-sync-standard",
      name: "Sync recent meetings",
      callback: () => this.triggerSync("standard")
    });
    this.addCommand({
      id: "fathom-sync-full",
      name: "Full sync (all meetings)",
      callback: () => this.triggerSync("full")
    });
    this.addSettingTab(new FathomSyncSettingTab(this.app, this));
    this.reschedulePeriodicSync();
    logger.info("Plugin loaded.");
  }
  onunload() {
    this.clearPeriodicSync();
    logger.info("Plugin unloaded.");
  }
  // ── Public API (called from settings tab) ──────────────────────────
  async performSync(mode) {
    await this.triggerSync(mode);
  }
  reschedulePeriodicSync() {
    this.clearPeriodicSync();
    if (!this.settings.periodicSyncEnabled) return;
    const ms = this.settings.periodicSyncIntervalMinutes * 60 * 1e3;
    this.periodicSyncIntervalId = window.setInterval(
      () => this.triggerSync("standard"),
      ms
    );
    this.register(() => this.clearPeriodicSync());
  }
  // ── Settings ────────────────────────────────────────────────────────
  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }
  async saveSettings() {
    await this.saveData(this.settings);
    this.initServices();
  }
  // ── Internal ────────────────────────────────────────────────────────
  initServices() {
    this.fileSync = new FileSyncService(this.app);
    this.syncService = new SyncService(
      this.settings,
      this.fileSync,
      async (partial) => {
        Object.assign(this.settings, partial);
        await this.saveData(this.settings);
      }
    );
  }
  async triggerSync(mode) {
    this.setStatusBar("Syncing\u2026");
    const label = mode === "full" ? "full sync" : "sync";
    try {
      const result = await this.syncService.performSync(mode);
      const msg = `Fathom Sync: ${label} done \u2014 ${result.summariesCreated} summaries, ${result.transcriptsCreated} transcripts created.`;
      new import_obsidian5.Notice(msg);
      this.setStatusBar(`Last sync: ${(/* @__PURE__ */ new Date()).toLocaleTimeString()}`);
    } catch (err) {
      logger.error(`${label} failed`, err);
      const msg = err instanceof Error ? err.message : "Unknown error";
      new import_obsidian5.Notice(`Fathom Sync: ${label} failed \u2014 ${msg}`);
      this.setStatusBar("Sync failed");
    }
  }
  setStatusBar(text) {
    this.statusBarItem.setText(text);
  }
  clearPeriodicSync() {
    if (this.periodicSyncIntervalId !== null) {
      window.clearInterval(this.periodicSyncIntervalId);
      this.periodicSyncIntervalId = null;
    }
  }
};
